// Configuración de Supabase
const SUPABASE_URL = 'https://zicowjlhaopgamhesqcz.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InppY293amxoYW9wZ2FtaGVzcWN6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEwMDI2MDYsImV4cCI6MjA4NjU3ODYwNn0.3r8kYbgjmEzj2zADZOHL3V0kH05_I8gi0hdVMu_odzA';

// Función para generar UUID v4
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Función para hacer peticiones a Supabase
async function supabaseRequest(endpoint, method = 'GET', data = null) {
  const url = `${SUPABASE_URL}${endpoint}`;
  
  const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json'
  };

  const options = {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined
  };

  try {
    const response = await fetch(url, options);
    const responseData = await response.text();
    return {
      code: response.status,
      response: responseData
    };
  } catch (error) {
    console.error('Error en petición a Supabase:', error);
    return {
      code: 500,
      response: error.message
    };
  }
}

// Función para parsear form-urlencoded
function parseFormData(body) {
  const params = new URLSearchParams(body);
  const result = {};
  for (const [key, value] of params) {
    result[key] = value;
  }
  return result;
}

// Manejador principal de la función Netlify
exports.handler = async (event) => {
  const timestamp = new Date().toISOString();
  console.log(`${timestamp} - ========== NUEVA NOTIFICACIÓN ==========`);
  console.log(`${timestamp} - Método: ${event.httpMethod}`);

  try {
    // Obtener datos enviados por ePayco
    let inputData = {};
    
    if (event.httpMethod === 'POST') {
      const contentType = event.headers['content-type'] || '';
      
      if (contentType.includes('application/json')) {
        inputData = JSON.parse(event.body || '{}');
      } else {
        // Form-urlencoded (lo más común en ePayco)
        inputData = parseFormData(event.body);
      }
    } else if (event.httpMethod === 'GET') {
      // Si es GET, tomar los query params
      inputData = event.queryStringParameters || {};
    }
    
    console.log(`${timestamp} - Datos recibidos:`, JSON.stringify(inputData));

    // Si no hay datos, responder error
    if (!inputData || Object.keys(inputData).length === 0) {
      console.log(`${timestamp} - ERROR: No se recibieron datos`);
      return {
        statusCode: 400,
        body: 'ERROR: No data received'
      };
    }

    // Extraer TODOS los campos posibles de ePayco
    const data = {
      // Campos principales
      ref_payco: inputData.ref_payco || inputData.x_ref_payco || '',
      transaction_id: inputData.transaction_id || inputData.x_transaction_id || '',
      amount: inputData.amount || inputData.x_amount || inputData.x_amount_ok || 0,
      currency: inputData.currency || inputData.x_currency_code || 'COP',
      cod_response: inputData.cod_response || inputData.x_cod_response || '',
      response: inputData.response || inputData.x_response || '',
      response_reason: inputData.response_reason || inputData.x_response_reason_text || '',
      franchise: inputData.franchise || inputData.x_franchise || '',
      payment_method: inputData.payment_method || inputData.banco || inputData.x_bank_name || inputData.franchise || '',
      date: inputData.date || inputData.x_transaction_date || '',
      
      // Campos extra que enviamos desde checkout.html
      extra1: inputData.extra1 || inputData.x_extra1 || '', // user_id
      extra2: inputData.extra2 || inputData.x_extra2 || '', // package_type
      extra3: inputData.extra3 || inputData.x_extra3 || '', // credits
      
      // Datos del cliente
      customer_name: inputData.customer_name || inputData.x_customer_name || '',
      customer_email: inputData.customer_email || inputData.x_customer_email || '',
      customer_document: inputData.customer_document || inputData.x_customer_document || ''
    };

    console.log(`${timestamp} - Datos procesados:`, JSON.stringify(data));

    // Normalizar estado según tabla de ePayco
    let statusNormalized = 'pendiente';
    let completed_at = null;

    // Códigos de respuesta ePayco: 1=Aceptada, 2=Rechazada, 3=Pendiente, 4=Fallida
    switch (data.cod_response) {
      case '1':
        statusNormalized = 'completado';
        completed_at = new Date().toISOString();
        console.log(`${timestamp} - ✅ Transacción ACEPTADA`);
        break;
      case '2':
        statusNormalized = 'rechazado';
        console.log(`${timestamp} - ❌ Transacción RECHAZADA - Motivo: ${data.response_reason}`);
        break;
      case '3':
        statusNormalized = 'pendiente';
        console.log(`${timestamp} - ⏳ Transacción PENDIENTE`);
        break;
      case '4':
        statusNormalized = 'rechazado';
        console.log(`${timestamp} - ❌ Transacción FALLIDA`);
        break;
      default:
        // Si no hay código pero hay respuesta textual
        if (data.response.toLowerCase().includes('aceptada') || data.response.toLowerCase().includes('aprobada')) {
          statusNormalized = 'completado';
          completed_at = new Date().toISOString();
        } else if (data.response.toLowerCase().includes('rechazada') || data.response.toLowerCase().includes('fallida')) {
          statusNormalized = 'rechazado';
        }
        break;
    }

    console.log(`${timestamp} - Estado normalizado: ${statusNormalized}`);

    // Verificar si ya existe la transacción por ref_payco
    const checkEndpoint = `/rest/v1/transacciones?transaction_id=eq.${encodeURIComponent(data.ref_payco)}`;
    const checkResult = await supabaseRequest(checkEndpoint, 'GET');

    if (checkResult.code === 200) {
      let existing = [];
      try {
        existing = JSON.parse(checkResult.response);
      } catch (e) {
        console.log(`${timestamp} - Error parseando respuesta:`, e);
      }
      
      if (!existing || existing.length === 0) {
        // SIEMPRE insertar la transacción, incluso si está rechazada o sin extra1
        
        // Si no tenemos user_id, lo dejamos null
        const userId = data.extra1 || null;
        
        // Si no tenemos extra2/extra3, intentamos determinarlos por el monto
        let credits_amount = parseInt(data.extra3) || 0;
        let package_type = data.extra2 || 'desconocido';
        
        // Si no hay extra3 pero hay monto, intentamos inferir el paquete
        if (credits_amount === 0 && data.amount > 0) {
          const amount = parseFloat(data.amount);
          if (amount === 24900) {
            credits_amount = 45;
            package_type = 'basico';
          } else if (amount === 44900) {
            credits_amount = 90;
            package_type = 'estandar';
          } else if (amount === 54900) {
            credits_amount = 180;
            package_type = 'premium';
          }
        }
        
        const transaccionData = {
          id: generateUUID(),
          user_id: userId,
          transaction_id: data.ref_payco,
          credits_amount: credits_amount,
          amount_paid: parseFloat(data.amount) || 0,
          currency: data.currency,
          package_type: package_type,
          status: statusNormalized,
          payment_method: data.payment_method || data.franchise || 'desconocido',
          completed_at: completed_at,
          created_at: new Date().toISOString()
        };
        
        console.log(`${timestamp} - Insertando transacción en Supabase:`, JSON.stringify(transaccionData));
        
        const insertResult = await supabaseRequest('/rest/v1/transacciones', 'POST', transaccionData);
        console.log(`${timestamp} - Resultado inserción - Código: ${insertResult.code} - Respuesta: ${insertResult.response}`);
        
        // SOLO actualizar créditos si la transacción fue COMPLETADA y tenemos user_id
        if (statusNormalized === 'completado' && userId && credits_amount > 0) {
          console.log(`${timestamp} - Procesando actualización de créditos para usuario: ${userId}`);
          
          // Obtener créditos actuales
          const userEndpoint = `/rest/v1/usuarios?id=eq.${encodeURIComponent(userId)}`;
          const userResult = await supabaseRequest(userEndpoint, 'GET');
          
          if (userResult.code === 200) {
            let users = [];
            try {
              users = JSON.parse(userResult.response);
            } catch (e) {
              console.log(`${timestamp} - Error parseando usuario:`, e);
            }
            
            if (users && users.length > 0) {
              const currentCredits = users[0].credits || 0;
              const newCredits = currentCredits + credits_amount;
              
              console.log(`${timestamp} - Actualizando créditos: ${currentCredits} + ${credits_amount} = ${newCredits}`);
              
              const updateResult = await supabaseRequest(`/rest/v1/usuarios?id=eq.${encodeURIComponent(userId)}`, 'PATCH', {
                credits: newCredits
              });
              
              console.log(`${timestamp} - Resultado actualización: ${updateResult.code}`);
            }
          }
        }
      } else {
        console.log(`${timestamp} - La transacción YA EXISTE, actualizando estado si es necesario`);
        
        // Si la transacción existe pero el estado cambió
        if (existing[0].status !== statusNormalized) {
          const updateData = { status: statusNormalized };
          if (statusNormalized === 'completado') {
            updateData.completed_at = new Date().toISOString();
          }
          
          const updateResult = await supabaseRequest(`/rest/v1/transacciones?transaction_id=eq.${encodeURIComponent(data.ref_payco)}`, 'PATCH', updateData);
          console.log(`${timestamp} - Estado actualizado: ${updateResult.code}`);
        }
      }
    } else {
      console.log(`${timestamp} - ERROR consultando Supabase: ${checkResult.response}`);
    }

    // SIEMPRE responder OK para que ePayco no reintente
    console.log(`${timestamp} - ========== FIN NOTIFICACIÓN ==========\n`);
    
    return {
      statusCode: 200,
      body: 'OK'
    };

  } catch (error) {
    console.error(`${timestamp} - ERROR CRÍTICO:`, error);
    return {
      statusCode: 500,
      body: 'ERROR: ' + error.message
    };
  }
};